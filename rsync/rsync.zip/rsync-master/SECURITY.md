# Security Policy

## Supported Versions

Only the current release of the software is actively supported.  If you need
help backporting fixes into an older release, feel free to ask.

## Reporting a Vulnerability

Email your vulnerability information to rsync's maintainer:

  Wayne Davison <wayne@opencoder.net>
